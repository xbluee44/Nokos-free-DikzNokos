module.exports = {
    // API Keys
    API1_KEY: '74dfdc8997c648549129c71a7f2d50c4',
    API5SIM_KEY: 'eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3OTYzMDE4OTIsImlhdCI6MTc2NDc2NTg5MiwicmF5IjoiNzJkMzg0NjIyZGE5MDMxZDNhYWJmNTU3NTM4ZGE1ZmQiLCJzdWIiOjM2NDUwNzl9.Cqdu0DLkbcqjm86Hr60lZxQCUTND5yo71sNSqIgL5ERLt4QFvdodwUhfPqifnUnzOzyRnq_oBntFSnakfvI06Z95reL7V_Ut_AGhFBT8WMvizPydi0OR5T90BQfWDqM8wp1tM3W84H7AcHcx6-0FcV10ipD-VFatpBNIsIvhgqWZ3C24ZdNlTyTLyIwyVk_ifWZv6OnjjTdBEMyjek7cePbuc8cDtXjq_O5XKgqzNKpiR6cNDq9hYrm6uPcvqWU_WD1AfLnZm5Od-3Zu8UFd2O2Xj_J-6iW0Iohcg7RDi86PMxgpP1ctj_SMVDJTbDBASgGciNOM7smQNxvXCiTqTA',
    
    // Token Nokos (Unlimited)
    NOKOS_TOKEN: 'DIKZX_NOKOS_FREE_TOKEN_UNLIMITED_2025',
    
    // Admin Credentials
    ADMIN_USERNAME: 'DikzxNokos',
    ADMIN_PASSWORD: 'AdminDikzx162',
    
    // Jeda waktu (3 menit dalam milidetik)
    COOLDOWN_TIME: 3 * 60 * 1000,
    
    // ID Characters
    ID_CHARS: '0123456789abcdefghijklmnopqrstuvwxyz',
    ID_LENGTH: 10,
    
    // MongoDB URL (ganti dengan URL database Anda)
    MONGODB_URI: 'mongodb://localhost:27017/dikzx_nokos'
};