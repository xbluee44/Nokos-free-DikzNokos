const express = require('express');
const router = express.Router();
const UserID = require('../models/UserID');
const LoginHistory = require('../models/LoginHistory');
const config = require('../config');

// Login User dengan ID
router.post('/login', async (req, res) => {
    try {
        const { user_id } = req.body;
        
        if (!user_id) {
            return res.status(400).json({ 
                success: false, 
                error: 'User ID diperlukan' 
            });
        }
        
        // Cari user ID
        const user = await UserID.findOne({ user_id: user_id });
        
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'User ID tidak ditemukan' 
            });
        }
        
        // Cek status user
        if (user.status !== 'active') {
            return res.status(403).json({ 
                success: false, 
                error: 'User ID belum diaktifkan oleh admin' 
            });
        }
        
        // Cek apakah user sudah online
        if (user.is_online) {
            return res.status(409).json({ 
                success: false, 
                error: 'ID sudah login, gunakan ID yang lain' 
            });
        }
        
        // Update status online dan waktu login
        user.is_online = true;
        user.last_login = new Date();
        await user.save();
        
        // Simpan history login
        const loginHistory = new LoginHistory({
            user_id: user_id,
            ip_address: req.ip,
            user_agent: req.headers['user-agent']
        });
        
        await loginHistory.save();
        
        // Buat session token untuk user
        const userToken = Buffer.from(`${user_id}:${Date.now()}`).toString('base64');
        
        res.json({
            success: true,
            message: 'Login berhasil',
            user_id: user_id,
            token: userToken,
            user: {
                id: user_id,
                last_login: user.last_login,
                created_at: user.created_at
            }
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Logout User
router.post('/logout', async (req, res) => {
    try {
        const { user_id } = req.body;
        
        if (!user_id) {
            return res.status(400).json({ 
                success: false, 
                error: 'User ID diperlukan' 
            });
        }
        
        const user = await UserID.findOne({ user_id: user_id });
        
        if (user) {
            user.is_online = false;
            await user.save();
            
            // Update logout time in history
            const latestLogin = await LoginHistory.findOne({ 
                user_id: user_id,
                logout_time: null 
            }).sort({ login_time: -1 });
            
            if (latestLogin) {
                latestLogin.logout_time = new Date();
                latestLogin.duration = latestLogin.logout_time - latestLogin.login_time;
                await latestLogin.save();
            }
        }
        
        res.json({
            success: true,
            message: 'Logout berhasil'
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Cek Status User
router.get('/status/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const user = await UserID.findOne({ user_id: id });
        
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'User ID tidak ditemukan' 
            });
        }
        
        res.json({
            success: true,
            user_id: user.user_id,
            status: user.status,
            is_online: user.is_online,
            last_login: user.last_login,
            created_at: user.created_at
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

module.exports = router;