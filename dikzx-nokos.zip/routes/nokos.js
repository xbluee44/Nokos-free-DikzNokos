const express = require('express');
const router = express.Router();
const UserID = require('../models/UserID');
const NokosHistory = require('../models/NokosHistory');
const config = require('../config');

// Generate Nokos Free
router.post('/generate', async (req, res) => {
    try {
        const { user_id, token } = req.body;
        
        if (!user_id || !token) {
            return res.status(400).json({ 
                success: false, 
                error: 'User ID dan token diperlukan' 
            });
        }
        
        // Verifikasi token
        if (token !== config.NOKOS_TOKEN) {
            return res.status(401).json({ 
                success: false, 
                error: 'Token tidak valid' 
            });
        }
        
        // Cek user
        const user = await UserID.findOne({ user_id: user_id });
        
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'User ID tidak ditemukan' 
            });
        }
        
        if (user.status !== 'active') {
            return res.status(403).json({ 
                success: false, 
                error: 'User ID belum diaktifkan' 
            });
        }
        
        // Cek cooldown
        const lastNokos = await NokosHistory.findOne({ 
            user_id: user_id 
        }).sort({ created_at: -1 });
        
        if (lastNokos && lastNokos.cooldown_until) {
            const now = new Date();
            if (now < new Date(lastNokos.cooldown_until)) {
                const remainingTime = Math.ceil(
                    (new Date(lastNokos.cooldown_until) - now) / 1000 / 60
                );
                return res.status(429).json({ 
                    success: false, 
                    error: `JEDA ${remainingTime} MENIT JANGAN PAKSA!` 
                });
            }
        }
        
        // Generate Nokos Data
        const nokosData = {
            id: Math.floor(10000000 + Math.random() * 90000000),
            phone: `+44${Math.floor(700000000 + Math.random() * 300000000)}`,
            operator: "vodafone",
            product: "facebook",
            price: 21,
            status: "PENDING",
            expires: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 menit dari sekarang
            sms: null,
            created_at: new Date().toISOString(),
            forwarding: false,
            forwarding_number: "",
            country: "england"
        };
        
        // Simpan ke history
        const nokosHistory = new NokosHistory({
            user_id: user_id,
            nokos_data: nokosData,
            token_used: token,
            cooldown_until: new Date(Date.now() + config.COOLDOWN_TIME)
        });
        
        await nokosHistory.save();
        
        res.json({
            success: true,
            message: 'Nokos berhasil digenerate',
            data: nokosData,
            cooldown_until: nokosHistory.cooldown_until,
            next_available: '3 menit dari sekarang'
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Get Nokos History User
router.get('/history/:user_id', async (req, res) => {
    try {
        const { user_id } = req.params;
        const { limit = 10 } = req.query;
        
        const history = await NokosHistory.find({ user_id: user_id })
            .sort({ created_at: -1 })
            .limit(parseInt(limit));
        
        res.json({
            success: true,
            total: history.length,
            history: history.map(h => ({
                id: h.nokos_data.id,
                phone: h.nokos_data.phone,
                product: h.nokos_data.product,
                created_at: h.created_at,
                status: h.nokos_data.status
            }))
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Cek Cooldown
router.get('/cooldown/:user_id', async (req, res) => {
    try {
        const { user_id } = req.params;
        
        const lastNokos = await NokosHistory.findOne({ 
            user_id: user_id 
        }).sort({ created_at: -1 });
        
        if (!lastNokos || !lastNokos.cooldown_until) {
            return res.json({
                success: true,
                on_cooldown: false,
                message: 'Bisa membuat nokos baru'
            });
        }
        
        const now = new Date();
        const cooldownUntil = new Date(lastNokos.cooldown_until);
        
        if (now >= cooldownUntil) {
            return res.json({
                success: true,
                on_cooldown: false,
                message: 'Bisa membuat nokos baru'
            });
        }
        
        const remainingSeconds = Math.ceil((cooldownUntil - now) / 1000);
        const remainingMinutes = Math.ceil(remainingSeconds / 60);
        
        res.json({
            success: true,
            on_cooldown: true,
            remaining_seconds: remainingSeconds,
            remaining_minutes: remainingMinutes,
            cooldown_until: cooldownUntil,
            message: `JEDA ${remainingMinutes} MENIT LAGI`
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

module.exports = router;