const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const UserID = require('../models/UserID');
const LoginHistory = require('../models/LoginHistory');
const NokosHistory = require('../models/NokosHistory');
const config = require('../config');

// Middleware untuk cek admin
const authenticateAdmin = (req, res, next) => {
    const token = req.headers['authorization'];
    
    if (!token) {
        return res.status(401).json({ error: 'Akses ditolak. Token diperlukan.' });
    }
    
    try {
        const decoded = jwt.verify(token.replace('Bearer ', ''), 'admin_secret_key');
        req.admin = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Token tidak valid.' });
    }
};

// Login Admin
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (username === config.ADMIN_USERNAME && password === config.ADMIN_PASSWORD) {
        const token = jwt.sign(
            { username: username, role: 'admin' },
            'admin_secret_key',
            { expiresIn: '24h' }
        );
        
        res.json({
            success: true,
            message: 'Login berhasil',
            token: token,
            admin: {
                username: username
            }
        });
    } else {
        res.status(401).json({ 
            success: false, 
            error: 'Username atau password salah' 
        });
    }
});

// Generate User ID Baru
router.post('/generate-user-id', authenticateAdmin, async (req, res) => {
    try {
        const { count = 1 } = req.body;
        const generatedIds = [];
        
        for (let i = 0; i < count; i++) {
            let newId;
            let isUnique = false;
            
            // Generate unique ID
            while (!isUnique) {
                newId = '';
                for (let j = 0; j < config.ID_LENGTH; j++) {
                    newId += config.ID_CHARS.charAt(
                        Math.floor(Math.random() * config.ID_CHARS.length)
                    );
                }
                
                // Check if ID already exists
                const existingId = await UserID.findOne({ user_id: newId });
                if (!existingId) {
                    isUnique = true;
                }
            }
            
            // Create new user ID
            const userID = new UserID({
                user_id: newId,
                status: 'inactive',
                created_by: req.admin.username
            });
            
            await userID.save();
            generatedIds.push(newId);
        }
        
        res.json({
            success: true,
            message: `Berhasil generate ${count} user ID`,
            user_ids: generatedIds
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Get All User IDs
router.get('/user-ids', authenticateAdmin, async (req, res) => {
    try {
        const users = await UserID.find().sort({ created_at: -1 });
        
        res.json({
            success: true,
            total_users: users.length,
            users: users
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Toggle Status User
router.put('/toggle-user/:id', authenticateAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const user = await UserID.findOne({ user_id: id });
        
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'User ID tidak ditemukan' 
            });
        }
        
        user.status = user.status === 'active' ? 'inactive' : 'active';
        user.is_online = false; // Reset status online
        
        await user.save();
        
        res.json({
            success: true,
            message: `Status user ${id} berhasil diubah menjadi ${user.status}`,
            user: user
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Get Login History
router.get('/login-history', authenticateAdmin, async (req, res) => {
    try {
        const { page = 1, limit = 50 } = req.query;
        const skip = (page - 1) * limit;
        
        const history = await LoginHistory.find()
            .sort({ login_time: -1 })
            .skip(skip)
            .limit(parseInt(limit));
        
        const total = await LoginHistory.countDocuments();
        
        res.json({
            success: true,
            total_records: total,
            page: parseInt(page),
            total_pages: Math.ceil(total / limit),
            history: history
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Get Nokos History
router.get('/nokos-history', authenticateAdmin, async (req, res) => {
    try {
        const { page = 1, limit = 50 } = req.query;
        const skip = (page - 1) * limit;
        
        const history = await NokosHistory.find()
            .sort({ created_at: -1 })
            .skip(skip)
            .limit(parseInt(limit));
        
        const total = await NokosHistory.countDocuments();
        
        res.json({
            success: true,
            total_records: total,
            page: parseInt(page),
            total_pages: Math.ceil(total / limit),
            history: history
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

// Get Dashboard Stats
router.get('/dashboard', authenticateAdmin, async (req, res) => {
    try {
        const totalUsers = await UserID.countDocuments();
        const activeUsers = await UserID.countDocuments({ status: 'active' });
        const onlineUsers = await UserID.countDocuments({ is_online: true });
        const totalLogins = await LoginHistory.countDocuments();
        const totalNokos = await NokosHistory.countDocuments();
        
        // Last 24 hours activity
        const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
        const recentLogins = await LoginHistory.countDocuments({ 
            login_time: { $gte: last24Hours } 
        });
        const recentNokos = await NokosHistory.countDocuments({ 
            created_at: { $gte: last24Hours } 
        });
        
        res.json({
            success: true,
            stats: {
                total_users: totalUsers,
                active_users: activeUsers,
                online_users: onlineUsers,
                total_logins: totalLogins,
                total_nokos: totalNokos,
                recent_logins_24h: recentLogins,
                recent_nokos_24h: recentNokos
            }
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

module.exports = router;