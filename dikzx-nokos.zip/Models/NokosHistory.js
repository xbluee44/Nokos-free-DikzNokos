const mongoose = require('mongoose');

const NokosHistorySchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true
    },
    nokos_data: {
        type: Object,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    token_used: {
        type: String,
        required: true
    },
    cooldown_until: {
        type: Date,
        default: null
    }
});

module.exports = mongoose.model('NokosHistory', NokosHistorySchema);