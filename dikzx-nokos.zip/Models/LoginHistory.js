const mongoose = require('mongoose');

const LoginHistorySchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true
    },
    ip_address: {
        type: String
    },
    user_agent: {
        type: String
    },
    login_time: {
        type: Date,
        default: Date.now
    },
    logout_time: {
        type: Date,
        default: null
    },
    duration: {
        type: Number,
        default: 0
    }
});

module.exports = mongoose.model('LoginHistory', LoginHistorySchema);