const mongoose = require('mongoose');

const UserIDSchema = new mongoose.Schema({
    user_id: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    status: {
        type: String,
        enum: ['active', 'inactive'],
        default: 'inactive'
    },
    is_online: {
        type: Boolean,
        default: false
    },
    last_login: {
        type: Date,
        default: null
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    created_by: {
        type: String,
        default: 'admin'
    },
    note: {
        type: String,
        default: ''
    }
});

module.exports = mongoose.model('UserID', UserIDSchema);